library(testthat)
library(cif)

test_check("cif")
